package com.example.cam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

public class MainActivityAIR extends AppCompatActivity {

    private TextView nilaiAir;

    private Firebase Air;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_air);

        nilaiAir = (TextView)findViewById(R.id.nilaiAir);

        Air = new Firebase("https://sanjayafarm-8f453-default-rtdb.firebaseio.com/Ketinggian Air/data");

        Air.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String data =dataSnapshot.getValue(String.class);
                nilaiAir.setText(data);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
    }
}