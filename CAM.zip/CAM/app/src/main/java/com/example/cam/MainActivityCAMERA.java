package com.example.cam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

public class MainActivityCAMERA extends AppCompatActivity {

    private TextView nilaiKAMERA;

    private Firebase CAM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_camera);

        nilaiKAMERA = (TextView)findViewById(R.id.nilaiKAMERA);

        CAM = new Firebase("https://sanjayafarm-8f453-default-rtdb.firebaseio.com/kamera");

        CAM.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String kamera = dataSnapshot.getValue(String.class);
                nilaiKAMERA.setText(kamera);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
    }
}